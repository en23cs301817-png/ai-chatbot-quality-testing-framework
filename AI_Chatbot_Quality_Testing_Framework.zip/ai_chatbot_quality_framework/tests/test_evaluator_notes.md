# Manual test checklist

- [ ] App starts with `streamlit run app.py`.
- [ ] Sample dataset loads without errors.
- [ ] Complete responses with expected-answer overlap pass.
- [ ] Empty or technical-error responses fail.
- [ ] Custom required terms fail when missing.
- [ ] Search and status filters work.
- [ ] Runs are saved in Evaluation history.
- [ ] CSV export opens correctly.
